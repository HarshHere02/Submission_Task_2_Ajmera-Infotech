import requests
from bs4 import BeautifulSoup
import csv
import logging

logging.basicConfig(level=logging.INFO)

def fetch_html(url):
    try:
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'}
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        return response.content
    except requests.exceptions.RequestException as e:
        logging.error(f"Failed to fetch the page. Error: {e}")
        return None

def extract_mobile_data(container):
    name_element = container.find('div', class_='_4rR01T')
    price_element = container.find('div', class_='_30jeq3')
    ratings_element = container.find('div', class_='_3LWZlK')

    # Check if the elements are found before accessing their text content
    if name_element and price_element and ratings_element:
        name = name_element.text.strip()
        price = price_element.text.strip()
        ratings = ratings_element.text.strip()

        return {
            'Name': name,
            'Price': price,
            'Ratings': ratings
            # Add more attributes as needed
        }
    return None

def scrape_flipkart_mobiles(query):
    base_url = "https://www.flipkart.com/search?q="
    url = base_url + query

    html_content = fetch_html(url)
    if html_content is None:
        return None

    # Parse the HTML content of the page using BeautifulSoup
    soup = BeautifulSoup(html_content, 'html.parser')

    # Extract mobile details from the parsed HTML
    mobiles = []
    for mobile_container in soup.find_all('div', class_='_1AtVbE'):
        mobile_data = extract_mobile_data(mobile_container)
        if mobile_data:
            mobiles.append(mobile_data)

    return mobiles

def save_to_csv(data, filename='flipkart_mobiles.csv'):
    # Save the extracted data to a CSV file
    try:
        with open(filename, 'w', newline='', encoding='utf-8') as csvfile:
            fieldnames = data[0].keys() if data else []
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

            writer.writeheader()
            for row in data:
                writer.writerow(row)
        logging.info(f"CSV file '{filename}' created successfully.")
    except Exception as e:
        logging.error(f"Failed to write to CSV. Error: {e}")

if __name__ == "__main__":
    query = "iPhone"
    
    # Scrape Flipkart mobiles based on the query
    mobiles_data = scrape_flipkart_mobiles(query)

    if mobiles_data:
        # Save the extracted data to a CSV file
        save_to_csv(mobiles_data)
    else:
        logging.warning("No data scraped.")
